
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:eatinom/Pages/App/AppConfig.dart';
import 'package:eatinom/Pages/Index/helper.dart';
import 'package:eatinom/Pages/Orders/OrderSummary.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hexcolor/hexcolor.dart';

class OrderSummaryNew extends StatefulWidget {
  OrderSummaryNew({Key key, this.title,this.selectedOrder1}) : super(key: key);
  final String title;
  DocumentSnapshot selectedOrder1;

  @override
  OrdersSum createState() => new OrdersSum();
}

class OrdersSum extends State<OrderSummaryNew>{

  String filterBy = 'All';
  // var v =int.parse('order.id.substring(order.id.length - 10,order.id.length).toUpperCase()');

  @override
  Widget build(BuildContext context) {
    AppConfig.context = context;

    ScreenUtil.init(context);
    ScreenUtil().allowFontScaling = false;



    return WillPopScope(

        child: Scaffold(
          backgroundColor: Colors.blue.withOpacity(0.03),
          body: Container(
              child: Stack(children: [
                Container(
                    margin: EdgeInsets.only(top: 50.0),
                    child: ordersList()
                ),
                Align(
                    alignment: Alignment.topLeft,
                    child: Container(
                        padding: EdgeInsets.only(right: 15.0, top: 0.0),
                        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,children: [
                          Padding(padding: EdgeInsets.only(left: 15.0), child: Text('Previous Orders',textScaleFactor: 1.0, style: TextStyle(color: Colors.black.withOpacity(0.4), fontSize: 18.0, fontFamily: 'Product Sans'))),

                          filterBox()
                        ])

                    )
                )
              ])
          ),
        ), onWillPop: Helper.of(context).onWillPop);


  }

  Widget showCard(DocumentSnapshot dt)
  //DocumentSnapshot dt
  {
    try{
      return Container(
        decoration: BoxDecoration(
          //borderRadius: BorderRadius.circular(10),
            color: Colors.white.withOpacity(1.0),
            boxShadow: [BoxShadow(
              color: Colors.black26,
              blurRadius: 0.5,
            )]
        ),
        child: Stack(children: [
          Column(
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,children: [
                  Container(
                      width: MediaQuery.of(context).size.width * 0.25,
                      child: Center(
                          child: widget.selectedOrder1.data().containsKey('ImageStr') ? FittedBox(child: Image.memory(base64Decode(widget.selectedOrder1['ImageStr']), height: 90.0,), fit: BoxFit.cover) : Icon(Icons.sort,size: 60.0,color: Colors.blueGrey.shade200,)
                      )
                  ),
                  Container(
                      width: MediaQuery.of(context).size.width * 0.75,
                      padding: EdgeInsets.all(10.0),
                      child: Column(children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(widget.selectedOrder1['Item_Name'],textScaleFactor: 1.0, overflow: TextOverflow.ellipsis,style: TextStyle(color: Colors.blueGrey, fontFamily: 'Product Sans', fontSize: 17.0,fontWeight: FontWeight.w600)),
                        ),
                        SizedBox(height: 3.0),
                   /*     Align(
                            alignment: Alignment.centerLeft,
                            child: Row(children: [
                              Text('HSN : ',textScaleFactor: 1.0, style: TextStyle(color: Colors.blueGrey.shade400, fontFamily: 'Product Sans', fontSize: 12.0)),
                              Text(widget.selectedOrder1['HSN'],textScaleFactor: 1.0, style: TextStyle(color: Colors.blueGrey.shade400, fontFamily: 'Product Sans', fontSize: 12.0))
                            ])
                        ),*/
                        SizedBox(height: 10.0),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,children: [
                          Text(
                            '\u20B9 '+widget.selectedOrder1['Price'].toString(),textScaleFactor: 1.0,
                            style: const TextStyle(
                              fontSize: 20.0,
                              color: Colors.deepOrangeAccent,
                            ),
                          ),
                          RichText(textScaleFactor: 1.0,
                              text: TextSpan(
                                text: 'Discount : ',
                                style: TextStyle(fontSize: 14.0,color: Colors.blueGrey.withOpacity(0.7), fontWeight: FontWeight.w400, fontFamily: 'Product Sans'),
                                children: <TextSpan>[
                                  TextSpan(text: dt['Quantity'].toString()+'  ', style: TextStyle(fontSize: 16.0,color: Colors.blueGrey,fontWeight: FontWeight.w600)),
                                ],
                              )
                          ),
                          RichText(textScaleFactor: 1.0,
                              text: TextSpan(
                                text: 'Quantity : ',
                                style: TextStyle(fontSize: 14.0,color: Colors.blueGrey.withOpacity(0.7), fontWeight: FontWeight.w400, fontFamily: 'Product Sans'),
                                children: <TextSpan>[
                                  TextSpan(text: widget.selectedOrder1['Quantity'].toString()+'  ', style: TextStyle(fontSize: 16.0,color: Colors.blueGrey,fontWeight: FontWeight.w600)),
                                ],
                              )
                          ),
                        ])

                      ])
                  )
                ]),
                widget.selectedOrder1['Order_Type'] == 'Pre' && widget.selectedOrder1.data().containsKey('Day_Slot') ?
                Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: HexColor('#F1E9DA'),
                    ),
                    padding: EdgeInsets.only(left: 10.0, right: 10.0, top: 5.0, bottom: 5.0),
                    margin: EdgeInsets.all(10.0),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,children: [
                      Text(widget.selectedOrder1['Day_Slot'], style: TextStyle(color: Colors.orange)),
                      Text(widget.selectedOrder1['Time_Slot'], style: TextStyle(color: Colors.orange))
                    ]
                    )
                ): SizedBox()
              ]),

        /*  Align(
              alignment: Alignment.topRight,
              child: Container(
                decoration: BoxDecoration(1
                  borderRadius: BorderRadius.circular(5),
                  color: widget.selectedOrder1['Order_Type'] == 'Instant' ? Colors.blueAccent.withOpacity(0.2) : Colors.deepPurple.withOpacity(0.2),
                ),
                margin: EdgeInsets.only(top: 10.0, right: 10.0),
                padding: EdgeInsets.only(left: 10.0,right: 10.0,top: 5.0,bottom: 5.0),
                child: Text(widget.selectedOrder1['Order_Type'],textScaleFactor: 1.0, style: TextStyle(color: widget.selectedOrder1['Order_Type'] == 'Instant' ? Colors.blueAccent : Colors.deepPurple, fontSize: 10.0,fontFamily: 'Product Sans')),
              )
          ),*/
        ]
        ),
      );
    }
    catch(err){
      return SizedBox();
    }
  }


  Widget filterBox(){
    return DropdownButton<String>(
      items: <String>['All','Confirmed', 'Delivered', 'Cancelled'].map((String value) {
        return new DropdownMenuItem<String>(
          value: value,
          child: new Text(value,textScaleFactor: 1.0, style: TextStyle(color: Colors.black.withOpacity(0.4))),
        );
      }).toList(),
      onChanged: (value) {
        this.setState(() {
          filterBy = value;
        });
      },
      icon: Icon(Icons.filter_alt_sharp, color: Colors.black.withOpacity(0.4),size: 20.0,),
      value: filterBy,
    );
  }

  Widget ordersList(){
    try{
      CollectionReference orders = FirebaseFirestore.instance.collection('Order').doc(widget.selectedOrder1.id).collection('Items');



      return SingleChildScrollView(
          padding: EdgeInsets.only(top: 10.0, bottom: 30.0),
          child: StreamBuilder<QuerySnapshot>(
             // stream: query,
              builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError) {
                  return Text('Something went wrong');
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Container(height: MediaQuery.of(context).size.height - (AppBar().preferredSize.height - kToolbarHeight + 200),child: Center(child: CircularProgressIndicator()));
                }

                List<Widget> lst = new List<Widget>();
                if(snapshot.hasData && snapshot.data.docs.length > 0){
                  snapshot.data.docs.forEach((doc) {
                    lst.add(showCard(doc));
                  });
                }
                return Column(
                  children: lst,
                );
              }
          )
      );
    }
    catch(err){
      print(err.toString());
      return Container(height: 300.0,child: Center(child: Text('Error while loading previous orders. ',textScaleFactor: 1.0, style: TextStyle(color: Colors.redAccent, fontSize: 16.0,fontFamily: 'Product Sans'),)));
    }
  }





}