import 'package:cloud_firestore/cloud_firestore.dart';

class CartHolder{
  int count;
  DocumentSnapshot item;
  String timeSlot;
  DateTime daySlot;



}