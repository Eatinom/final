import 'dart:developer';

import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/material.dart';

class ErrorHandling{

  static Future<void> NotifyError(e , s) async{

  }

}